
% All credits go to:                  
% Author:Ioannis Kessopoulos          
% Date Project Started: 28/05/2020    
% View      

function I = ambientLight(ka, Ia)
    
%Ypologizei to fwtismo shmeioy P poy prokyptei apo to diaxyto fws sto perivallon kai mas dinei thn entash ths trixrwmikhs poy anaklatai apo to shmeio 

    I = Ia .* ka;

end